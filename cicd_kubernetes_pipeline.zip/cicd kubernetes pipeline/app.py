from flask import Flask, jsonify
import os

app = Flask(__name__)

@app.get('/')
def home():
    return jsonify(message='Hello from Kubernetes!', version=os.getenv('APP_VERSION', 'local'), pod=os.getenv('HOSTNAME', 'unknown'))

@app.get('/healthz')
def healthz():
    return 'ok', 200

@app.get('/readyz')
def readyz():
    return 'ready', 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
