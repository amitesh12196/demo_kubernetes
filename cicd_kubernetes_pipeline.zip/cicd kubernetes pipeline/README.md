# Kubernetes CI/CD practice app

A tiny Flask app for practicing: commit -> test -> build -> push to GHCR -> deploy to Kubernetes.

## Local

```bash
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open http://localhost:8080, or build with `docker build -t demo-app:local .` and run `docker run --rm -p 8080:8080 demo-app:local`.

## Kubernetes

Replace `REPLACE_WITH_GITHUB_OWNER` in `k8s/deployment.yaml`, then run:

```bash
kubectl apply -f k8s/
kubectl -n demo-app get pods -o wide
kubectl -n demo-app rollout status deployment/demo-app
kubectl -n demo-app port-forward service/demo-app 8080:80
```

The deployment has two replicas and preferred pod anti-affinity, so a cluster with two schedulable worker nodes will normally place one replica on each. Verify using `kubectl -n demo-app get pods -o wide`.

## GitHub Actions

Push this repository to GitHub. Add a repository secret named `KUBE_CONFIG` containing the target cluster kubeconfig. For a real environment, use a narrowly scoped service-account kubeconfig rather than an admin config. Pull requests run tests; pushes to `main` build/publish a SHA-tagged image to GHCR and deploy it.

For a private GHCR package, create an imagePullSecret and reference it from the Deployment.
